package com.st.blue_sdk.board_catalog.models

enum class BoardStatus {
    NRND,
    ACTIVE
}