package com.st.blue_sdk.board_catalog.models

enum class BootLoaderType {
    NONE,
    CUSTOM,
    WB,
    SBSFU
}